# M2 交付给 M3

交付日期为 2026-11-23，来源为开发 run m2_development_20261119。
固定臂序为 recent_short、recent_long、tfidf、resolved_tfidf，正文预算依次为 128、512、256、256。效用 U = y − 0.5 × cost / 512，cost 计完整输入。
m3_handoff_abrupt_130100.csv 含 abrupt/130100 的 300 题、1200 行，每题四臂，唯一键为 (seed,t,arm)。按固定臂序传入成本并回连所选臂的 y、cost、utility、coverage、outdated。请回复是否可读取和回放；如有异常请附键与字段名。
